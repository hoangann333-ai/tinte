# JSP/Servlet Currency Converter

Ứng dụng Maven Web chuyển đổi USD sang VNĐ. Form gửi `rate` và `usd` bằng POST đến `/convert`; `ConverterServlet` kiểm tra dữ liệu và tính `VNĐ = USD × tỉ giá` bằng `BigDecimal`.

## Yêu cầu
- JDK 17+
- Maven 3.8+
- Apache Tomcat 10.1+

## Đóng gói WAR
Mở terminal tại thư mục có `pom.xml`, chạy:

```bash
mvn clean package
```

File triển khai: `target/jsp-servlet-currency-converter.war`.

## Chạy trên Tomcat
Chép WAR vào thư mục `webapps` của Tomcat, khởi động Tomcat bằng `bin\startup.bat` trên Windows hoặc `bin/startup.sh` trên macOS/Linux.

Mở: http://localhost:8080/jsp-servlet-currency-converter/

Tomcat 10.1 dùng Jakarta Servlet 6.0 và Jakarta Server Pages 3.1; các API được khai báo `provided` vì máy chủ cung cấp lúc chạy.
