package com.codegym;

import java.io.IOException;
import java.io.PrintWriter;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.NumberFormat;
import java.util.Locale;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet(name = "ConverterServlet", urlPatterns = "/convert")
public class ConverterServlet extends HttpServlet {
    private static final Locale VIETNAMESE = Locale.forLanguageTag("vi-VN");

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        response.setContentType("text/html;charset=UTF-8");

        try {
            BigDecimal rate = new BigDecimal(requiredParameter(request, "rate"));
            BigDecimal usd = new BigDecimal(requiredParameter(request, "usd"));

            if (rate.signum() <= 0 || usd.signum() < 0) {
                renderMessage(response, request, "Tỉ giá phải lớn hơn 0 và số USD không được âm.");
                return;
            }

            BigDecimal vnd = rate.multiply(usd).setScale(0, RoundingMode.HALF_UP);
            NumberFormat numberFormat = NumberFormat.getNumberInstance(VIETNAMESE);
            numberFormat.setMaximumFractionDigits(2);

            renderResult(response, request, rate, usd, vnd, numberFormat);
        } catch (IllegalArgumentException ex) {
            renderMessage(response, request, "Vui lòng nhập tỉ giá và lượng USD hợp lệ.");
        }
    }

    private String requiredParameter(HttpServletRequest request, String name) {
        String value = request.getParameter(name);
        if (value == null || value.isBlank()) {
            throw new IllegalArgumentException("Missing parameter: " + name);
        }
        return value.trim();
    }

    private void renderResult(HttpServletResponse response, HttpServletRequest request,
                              BigDecimal rate, BigDecimal usd, BigDecimal vnd,
                              NumberFormat numberFormat) throws IOException {
        try (PrintWriter out = response.getWriter()) {
            out.println("<!doctype html><html lang="vi"><head>");
            out.println("<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1">");
            out.println("<title>Kết quả chuyển đổi</title>");
            out.println("<style>body{font-family:Arial,sans-serif;background:#f1f5f9;display:grid;place-items:center;min-height:100vh;margin:0;padding:20px}.card{width:min(100%,520px);background:#fff;padding:36px;border-radius:16px;box-shadow:0 12px 40px #0f172a18;text-align:center}h1{color:#1b2a7a} .amount{font-size:clamp(1.8rem,7vw,3rem);font-weight:700;color:#16834a;word-break:break-word}.muted{color:#64748b;line-height:1.7}.btn{display:inline-block;margin-top:18px;padding:12px 20px;border-radius:7px;background:#1b2a7a;color:#fff;text-decoration:none}</style>");
            out.println("</head><body><main class="card"><h1>Kết quả chuyển đổi</h1>");
            out.println("<p class="muted">Tỉ giá: 1 USD = " + numberFormat.format(rate) + " VNĐ</p>");
            out.println("<p class="muted">Số tiền: " + numberFormat.format(usd) + " USD</p>");
            out.println("<p class="amount">" + numberFormat.format(vnd) + " VNĐ</p>");
            out.println("<a class="btn" href="" + request.getContextPath() + "/index.jsp">Chuyển đổi tiếp</a>");
            out.println("</main></body></html>");
        }
    }

    private void renderMessage(HttpServletResponse response, HttpServletRequest request, String message)
            throws IOException {
        response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
        try (PrintWriter out = response.getWriter()) {
            out.println("<!doctype html><html lang="vi"><head><meta charset="UTF-8"><title>Dữ liệu không hợp lệ</title></head>");
            out.println("<body style="font-family:Arial,sans-serif;text-align:center;margin:12vh 1rem;background:#f8fafc">");
            out.println("<h2 style="color:#b42318">" + message + "</h2>");
            out.println("<a href="" + request.getContextPath() + "/index.jsp">Quay lại biểu mẫu</a></body></html>");
        }
    }
}
