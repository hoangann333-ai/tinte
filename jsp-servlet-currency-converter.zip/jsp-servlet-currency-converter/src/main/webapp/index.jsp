<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<!doctype html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Chuyển đổi USD sang VNĐ</title>
    <style>
        * { box-sizing: border-box; }
        body { min-height:100vh; margin:0; display:grid; place-items:center; padding:24px; background:#f1f5f9; color:#1e293b; font-family:Arial,Helvetica,sans-serif; }
        .converter { width:min(100%,430px); padding:36px; border-radius:16px; background:#fff; box-shadow:0 16px 48px rgba(15,23,42,.12); }
        .eyebrow { color:#64748b; font-size:.82rem; font-weight:700; letter-spacing:.1em; text-transform:uppercase; }
        h1 { margin:10px 0 8px; color:#1b2a7a; font-size:1.8rem; }
        .intro { margin:0 0 26px; color:#64748b; line-height:1.5; }
        label { display:block; margin:16px 0 7px; font-weight:600; }
        input { width:100%; min-height:48px; padding:12px; border:1px solid #cbd5e1; border-radius:7px; font-size:1rem; }
        input:focus { outline:3px solid rgba(27,42,122,.15); border-color:#1b2a7a; }
        .hint { margin:6px 0 0; color:#64748b; font-size:.82rem; }
        button { width:100%; min-height:48px; margin-top:24px; border:0; border-radius:7px; background:#1b2a7a; color:#fff; font-size:1rem; font-weight:700; cursor:pointer; }
        button:hover { background:#121c54; }
        .formula { margin:20px 0 0; padding:12px; border-radius:7px; background:#f8fafc; color:#475569; text-align:center; font-size:.9rem; }
    </style>
</head>
<body>
    <main class="converter">
        <div class="eyebrow">Java Servlet Practice</div>
        <h1>Chuyển đổi USD sang VNĐ</h1>
        <p class="intro">Nhập tỉ giá và số USD. Servlet sẽ tính số tiền tương ứng bằng VNĐ.</p>

        <form action="${pageContext.request.contextPath}/convert" method="post">
            <label for="rate">Tỉ giá (VNĐ/USD)</label>
            <input type="number" id="rate" name="rate" value="25000" min="0.01" step="any" placeholder="Ví dụ: 25000" required>
            <p class="hint">Có thể thay đổi tỉ giá theo yêu cầu bài tập.</p>

            <label for="usd">Lượng USD cần đổi</label>
            <input type="number" id="usd" name="usd" min="0" step="any" placeholder="Ví dụ: 100" required>

            <button type="submit">Chuyển đổi</button>
        </form>
        <p class="formula">Công thức: VNĐ = USD × Tỉ giá</p>
    </main>
</body>
</html>
